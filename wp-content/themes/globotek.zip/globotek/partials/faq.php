<?php
/**
 * Created by PhpStorm.
 * User: matthew
 * Date: 6/4/19
 * Time: 6:11 PM
 */

$fields = get_fields(); ?>

<div class="faq">
    <div class="faq__body">
        <h4 class="faq__body__title title title__quaternary">HOW DOES SITE CARE WORK?</h4>
        <p class="faq__body__content">We will contact you to introduce ourselves and request credentials to your  site so that  we can make a copy of your live site. Then, we will create a sub-domain on globotek.net where the clone of your live site will live. Each month, we will synchronise our version to the live site so we’re working on the latest version. Once updates are completed in the safety of our copy, your live site will be updated.</p>
    </div>
</div>