<?php
/**
 * Created by PhpStorm.
 * User: matthew
 * Date: 5/4/19
 * Time: 12:35 PM
 */ ?>

<div class="section-title center">
	
	<h2 class="title__secondary"><?php echo $component[ 'title' ]; ?></h2>
	
	<?php if ( $component[ 'sub-title' ] ) { ?>
		
		<p class="section-title__intro"><?php echo $component[ 'sub-title' ]; ?></p>
	
	<?php } ?>

</div>

