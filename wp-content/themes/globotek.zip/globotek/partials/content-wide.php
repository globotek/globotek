<?php
/**
 * Created by PhpStorm.
 * User: matthew
 * Date: 9/4/19
 * Time: 5:50 PM
 */
?>

<div class="wrapper content">
	
	<?php the_content(); ?>

</div>
	